function [ y ] = heaveside( x )
if x >0
  y=1 ;
else
y=0 ;
end
end

